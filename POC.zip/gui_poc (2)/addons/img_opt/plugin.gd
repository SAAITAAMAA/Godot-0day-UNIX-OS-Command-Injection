@tool
extends EditorPlugin

class SimpleImporter:
	extends EditorImportPlugin
	
	func _get_importer_name():
		return "img.simple"
	
	func _get_visible_name():
		return "Simple Importer"
	
	func _get_recognized_extensions():
		return ["png"]
	
	func _get_save_extension():
		return "res"
	
	func _get_resource_type():
		return "Texture2D"
	
	func _get_preset_count():
		return 1
	
	func _get_preset_name(i):
		return "Default"
	
	func _get_priority():
		return 10.0
	
	func _get_import_order():
		return 0
	
	func _get_import_options(path, i):
		return []
	
	func _get_option_visibility(path, opt, opts):
		return true
	
	func _import(src, save, opts, pv, gf):
		var out = []
		OS.execute("echo", [src], out)
		print("Imported: ", src)
		return OK

var imp = null

func _enter_tree():
	imp = SimpleImporter.new()
	add_import_plugin(imp)
	print("Simple Importer enabled")

func _exit_tree():
	remove_import_plugin(imp)
	imp = null
